import { Routes, RouterModule } from '@angular/router';
import { CampaignlogsComponent } from './components/campaignlogs/campaignlogs.component';
import { GooglercsComponent } from './components/googlercs/googlercs.component';
import { XiaomircsComponent } from './components/xiaomircs/xiaomircs.component';

import { HomeComponent } from './home';
import { LoginComponent } from './login';
import { AuthGuard } from './_helpers';
import { UploadFileComponent } from './components/upload-file/upload-file.component';
import { CampaignComponent } from './components/campaign/campaign.component';
import { CreateCampaignComponent } from './components/create-campaign/create-campaign.component';
import { LeadComponent } from './components/lead/lead.component';
import { CreateLeadComponent } from './components/create-lead/create-lead.component';

const routes: Routes = [
    { path: '', component: CampaignComponent },
    { path: 'vircs', component: XiaomircsComponent },
    { path: 'Summary', component: GooglercsComponent },
    { path: 'detailreport', component: CampaignlogsComponent },
    { path: 'login', component: LoginComponent },
    { path: 'upload', component: UploadFileComponent },
    { path: 'campaignList', component: CampaignComponent },
    { path: 'campaign/create', component: CreateCampaignComponent },
    {path:'lead', component:LeadComponent},
    {path:'create/lead', component:CreateLeadComponent},

    // otherwise redirect to home
    // { path: '**', redirectTo: 'login' }
];

export const appRoutingModule = RouterModule.forRoot(routes);