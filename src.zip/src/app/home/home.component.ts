import { Component } from '@angular/core';
import { User } from '../_models';
import { AuthenticationService, UserService } from '../_services';

@Component({ 
    templateUrl: 'home.component.html',
    styleUrls: ['home.component.scss']

 })
export class HomeComponent {
    user?: User | null;

    constructor(private authenticationService: AuthenticationService) {
        this.authenticationService.user.subscribe(x => this.user = x);
    }

    logout() {
        this.authenticationService.logout();
    }
}