export const environment = {
  production: true,
  apiUrl: 'http://fuat.flash49.com/rcsmsg/auth/generateToken'
};
